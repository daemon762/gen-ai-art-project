# 🎨 AI Art Generator

This project uses Stable Diffusion to generate AI art from text prompts.

## 🧠 Requirements

- Python 3.8+
- Hugging Face account + token

## 🚀 How to Run

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Set your Hugging Face token:

```bash
export HUGGINGFACE_TOKEN=your_token_here
```

3. Run the app:

```bash
python app.py
```

It will open a web interface using Gradio.
