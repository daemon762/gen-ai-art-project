import gradio as gr
from diffusers import StableDiffusionPipeline
import torch
from utils import load_model

# Load model
pipe = load_model()

# Generate image
def generate(prompt):
    image = pipe(prompt).images[0]
    return image

# Gradio UI
demo = gr.Interface(fn=generate,
                    inputs=gr.Textbox(label="Enter your prompt", placeholder="A futuristic city at sunset..."),
                    outputs=gr.Image(type="pil"),
                    title="🎨 AI Art Generator",
                    description="Enter a prompt and get AI-generated art using Stable Diffusion!")

if __name__ == "__main__":
    demo.launch()
