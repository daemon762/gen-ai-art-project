from diffusers import StableDiffusionPipeline
import torch
import os

def load_model():
    model_id = "runwayml/stable-diffusion-v1-5"
    token = os.getenv("HUGGINGFACE_TOKEN")  # Set your token in environment variables

    pipe = StableDiffusionPipeline.from_pretrained(
        model_id,
        torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
        use_auth_token=token
    )

    pipe = pipe.to("cuda" if torch.cuda.is_available() else "cpu")
    return pipe
